@echo off
:x
start "video.mp4"
goto x