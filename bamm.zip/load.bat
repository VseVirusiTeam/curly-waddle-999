@echo off
:x
"video.mp4"
goto x